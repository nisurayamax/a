./rhminer -s pasc-eu1.nanopool.org:15556 -su YOUR_WALLET_ADDRESS.YOUR_PAYMENT_ID.YOUR_WORKER_NAME/YOUR_EMAIL -cpu -cputhreads 4 -r 40 -logfilename rhminer.log




